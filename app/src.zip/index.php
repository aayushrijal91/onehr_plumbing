<?php include __DIR__ . '/functions.php'; ?>

<?php include __DIR__ . '/src/header.php'; ?>

<?php include __DIR__ . '/src/main.php'; ?>

<?php include __DIR__ . '/src/footer.php'; ?>
