<?php 
$client_secret = '6LceIBwkAAAAAN0pB1ps__ZPUBNOme_2sFYJBNNn';
$server_secret = '6LceIBwkAAAAAOqRS49ww9XRHV3FR8wCssejhbbc';
?>