# Landing page [1hr Plumbing](www.aiims.com.au)

This is a landing page boilerplate that uses PHP scripting language

## _Author Information_

Developer: [Aayush Rijal](https://www.aayushrijal.net)

Contact: 0452637371

[Github](https://github.com/aayushrijal91/plumbfirst)

[Figma](https://www.figma.com/file/aD3aOaIohTgS7J5x7kmvwY/Plumbfirst-landing-page-minimal?node-id=1-3410&t=c8KFASZCbiCX7n7O-0)

## _Instruction_

```bash
 npm install
 npm start
 ```

Reference for full repository
